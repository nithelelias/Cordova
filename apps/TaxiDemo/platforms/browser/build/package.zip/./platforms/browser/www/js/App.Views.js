(function(){
		

	App.Angular.Views={

		"login":{
			"name":"Login & Register view",
			"url":"views/view.login.html"

		},
		"main":{
			"name":"Main view with map",
			"url":"views/view.main.html"
		}


	};

})();