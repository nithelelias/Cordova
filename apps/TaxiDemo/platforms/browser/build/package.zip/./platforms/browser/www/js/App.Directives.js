(function(){
	
	angular.module('MainApp') 
  

})();